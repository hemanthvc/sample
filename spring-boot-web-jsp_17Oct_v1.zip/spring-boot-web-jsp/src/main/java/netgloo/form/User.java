package netgloo.form;

import netgloo.contraint.EmailConstraint;
import netgloo.contraint.NameConstraint;
import netgloo.contraint.PasswordConstraint;
import netgloo.contraint.PhoneConstraint;
import netgloo.contraint.UserNameConstraint;

public class User {


    @UserNameConstraint
	 private String username;
	 
    
	 String password;
	 
	
    @PasswordConstraint
	String password1;
	 
	 String locked;
	 
	 String search;
	 
		public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

		public String getLocked() {
		return locked;
	}

	public void setLocked(String locked) {
		this.locked = locked;
	}

	

	public String getPassword1() {
		return password1;
	}

	public void setPassword1(String password1) {
		this.password1 = password1;
	}

	public String getPassword2() {
		return password2;
	}

	public void setPassword2(String password2) {
		this.password2 = password2;
	}

	public String getPassword3() {
		return password3;
	}

	public void setPassword3(String password3) {
		this.password3 = password3;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword4() {
		return password4;
	}

	public void setPassword4(String password4) {
		this.password4 = password4;
	}

	public String getPassword5() {
		return password5;
	}

	public void setPassword5(String password5) {
		this.password5 = password5;
	}

		String password2;
		String password3;
		String password4;
		String password5;
	 
	 
	 
	 @EmailConstraint
	String email;
	
	String country;
	String state;
	
	@NameConstraint
	String firstname;
	String lastname;
	String address;
	
	@PhoneConstraint
	String phone;
	
	String favouriteanswer;
	String newpassword;
	String role;
	String passwordUpdate;
	
	
	
	public String getPasswordUpdate() {
		return passwordUpdate;
	}

	public void setPasswordUpdate(String passwordUpdate) {
		this.passwordUpdate = passwordUpdate;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getFavouriteanswer() {
		return favouriteanswer;
	}

	public void setFavouriteanswer(String favouriteanswer) {
		this.favouriteanswer = favouriteanswer;
	}

	public String getNewpassword() {
		return newpassword;
	}

	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}

	

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	String secretQuestion;
	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getSecretAnswer() {
		return secretAnswer;
	}

	public void setSecretAnswer(String secretAnswer) {
		this.secretAnswer = secretAnswer;
	}

	String secretAnswer;
	

	public String getAddress() {
		return address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	String pincode;

	public String getFirstname() {
		return firstname;
	}

	public void setFirtname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	

	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	// getters and setters
}
