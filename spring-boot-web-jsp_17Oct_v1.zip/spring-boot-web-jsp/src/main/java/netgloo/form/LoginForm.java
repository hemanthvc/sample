package netgloo.form;

import netgloo.contraint.PasswordConstraint;
import netgloo.contraint.UserNameConstraint;

public class LoginForm {
    @UserNameConstraint
	 private String username;
    
    @PasswordConstraint
	String password1;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword1() {
		return password1;
	}

	public void setPassword1(String password1) {
		this.password1 = password1;
	}
}
