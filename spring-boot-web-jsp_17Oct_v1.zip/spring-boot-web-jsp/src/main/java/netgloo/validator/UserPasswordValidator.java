package netgloo.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import netgloo.contraint.PasswordConstraint;

public class UserPasswordValidator implements
  ConstraintValidator<PasswordConstraint, String> {
 
    @Override
    public void initialize(PasswordConstraint contactNumber) {
    	
    }
 
    @Override
    public boolean isValid(String contactField,
      ConstraintValidatorContext cxt) {
    	System.out.println("*********isValid*********"+contactField);
    	cxt.disableDefaultConstraintViolation();
    	
    	
        return checkConstraint1(contactField,cxt);
    }
    
 // Note: A private method for each constraint decreases the cyclomatic complexity.
    private boolean checkConstraint1(String contactField, ConstraintValidatorContext context) {
        // Default validity is true until proven otherwise.
        boolean valid = true;
        

        if ("".equalsIgnoreCase(contactField) || contactField == null  ) {
            valid = false;
            System.out.println("entered--1--");
            context.buildConstraintViolationWithTemplate(	
               "Password cannot be blank").addConstraintViolation();
        }else if(contactField != null && contactField.length() < 8){
       	 valid = false;
         System.out.println("entered 3----");
         context.buildConstraintViolationWithTemplate(
            "Password should contain atleast 8 characters").addConstraintViolation();
        
        }

        return valid;
    }
    
  
    

}
