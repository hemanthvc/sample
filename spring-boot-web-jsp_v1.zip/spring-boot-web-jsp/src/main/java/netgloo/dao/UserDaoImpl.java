package netgloo.dao;

import javax.transaction.Transactional;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Repository;

import netgloo.config.GetMongoDBConnection;
import netgloo.form.User;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {


	@Override
	public void saveUser(User user) {
		// TODO Auto-generated method stub
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		
		mongoOperation.save(user, "tableA");
	}

	/*@Override
	public List<User> getAllAccountDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateAccountDetails(String userId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAccountDetailsByName(String name) {
		// TODO Auto-generated method stub

	}

	@Override
	public String deleteAccount(String userId) {
		// TODO Auto-generated method stub
		return null;
	}*/
}
// class UserMapper implements RowMapper<User> {
// public User mapRow(ResultSet rs, int arg1) throws SQLException {
// User user = new User();
// user.setUsername(rs.getString("username"));
// user.setPassword(rs.getString("password"));
// user.setFirstname(rs.getString("firstname"));
// user.setLastname(rs.getString("lastname"));
// user.setEmail(rs.getString("email"));
// user.setAddress(rs.getString("address"));
// user.setPhone(rs.getInt("phone"));
// return user;
// }
