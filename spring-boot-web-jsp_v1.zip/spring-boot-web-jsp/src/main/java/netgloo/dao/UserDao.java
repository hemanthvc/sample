package netgloo.dao;

import netgloo.form.User;

public interface UserDao {
	void saveUser(User user);

	//List<User> getAllAccountDetails();

	//void updateAccountDetails(String userId);

	//void updateAccountDetailsByName(String name);

	//String deleteAccount(String userId);

}