package netgloo.service;

import java.util.List;

import netgloo.form.User;

public interface UserService {

	void saveUser(User user);

	List<User> getAllAccountDetails();

	void updateAccountDetails(String userId);

	void updateAccountDetailsByName(String name);

	String deleteAccount(String userId);
}
