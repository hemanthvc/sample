package netgloo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import netgloo.dao.UserDao;
import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import netgloo.models.UserRoles;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	@Override
	public String saveUser(User user) {
		return userDao.saveUser(user);
	}

	@Override
	public List<User> getAllAccountDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateAccountDetails(String userId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAccountDetailsByName(String name) {
		// TODO Auto-generated method stub

	}

	@Override
	public String deleteAccount(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<netgloo.models.User> getUsers(String user) {
		// TODO Auto-generated method stub
		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userDao.getUsers(user);
		return users;
	}

	@Override
	public List<Country> getCountry() {
		// TODO Auto-generated method stub
		List<Country> country = new ArrayList<Country>();
		country = userDao.getCountry();
		return country;
	}

	@Override
	public List<States> getStates(String country) {
		// TODO Auto-generated method stub
		List<States> states = new ArrayList<States>();
		states = userDao.getStates(country);
		return states;
	}

	@Override
	public List<UserRoles> getUserRoles() {
		// TODO Auto-generated method stub
		List<UserRoles> roles = new ArrayList<UserRoles>();
		roles = userDao.getUserRoles();
		return roles;
	}

	@Override
	public String validateUser(String username,String password) {
		// TODO Auto-generated method stub
		String result = userDao.validateUser(username,password);
		return result;
	}

	@Override
	public List<netgloo.models.User> editUser(User user) {
		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userDao.editUser(user);
		return users;
	}

	@Override
	public List<netgloo.models.User> deleteUser(String username) {
		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userDao.deleteUser(username);
		return users;
	}

	@Override
	public netgloo.models.User getUser(User user) {
		netgloo.models.User users = new netgloo.models.User();
		users = userDao.getUser(user);
		return users;
	}
	
	@Override
	public netgloo.models.User getUserLike(User user) {
		netgloo.models.User users = new netgloo.models.User();
		users = userDao.getUserLike(user);
		return users;
	}

	@Override
	public netgloo.models.User getSecretQuestion(String userId) {
		netgloo.models.User users = new netgloo.models.User();
		users= userDao.getSecretQuestion(userId);
		return users;
	}

	@Override
	public netgloo.models.User resetPassword(String oldpassword, String password,String username) {
		netgloo.models.User users = new netgloo.models.User();
		users = userDao.resetPassword(oldpassword, password, username);
		return users;
	}

	@Override
	public netgloo.models.User validateSecretQuestion(String userId, String question) {
		netgloo.models.User users = new netgloo.models.User();
		users= userDao.validateSecretQuestion(userId,question);
		return users;
	}

}
