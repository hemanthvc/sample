package netgloo.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;

public class GetMongoDBConnection {

	private static Logger logger = LoggerFactory.getLogger(GetMongoDBConnection.class);
	
	public static MongoOperations getConnection() {
		// For Annotation
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
		MongoOperations mongoOperation = (MongoOperations) ctx.getBean("mongoTemplate");

		logger.debug("GEtting DB connection ..........");
		return mongoOperation;
	}
}
