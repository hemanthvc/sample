package netgloo.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import com.mongodb.MongoClient;

/**
 * Spring MongoDB configuration file
 *
 */
@Configuration
public class SpringMongoConfig{

	private static Logger logger = LoggerFactory.getLogger(SpringMongoConfig.class);
	
	public @Bean
	MongoTemplate mongoTemplate() throws Exception {
		
		MongoTemplate mongoTemplate =
			new MongoTemplate(new MongoClient("127.0.0.1"),"local");
		logger.debug("getting mongoTemplate() ");
		
		return mongoTemplate;

	}
	
	@Bean
    public MongoClient createConnection() {
		logger.debug("getting createConnection() ");
        //You should put your mongo ip here
        return new MongoClient("localhost:27017");
    }

}
