package netgloo.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import netgloo.contraint.*;
import netgloo.util.ValidationUtil;

public class UserValidator implements
  ConstraintValidator<UserNameConstraint, String> {
 
	private static Logger logger = LoggerFactory.getLogger(UserValidator.class);
	
    @Override
    public void initialize(UserNameConstraint contactNumber) {
    	
    }
 
    @Override
    public boolean isValid(String contactField,
      ConstraintValidatorContext cxt) {
    	logger.debug("*********isValid*********"+contactField);
    	cxt.disableDefaultConstraintViolation();
    	
    	
        return checkConstraint1(contactField,cxt);
    }
    
 // Note: A private method for each constraint decreases the cyclomatic complexity.
    private boolean checkConstraint1(String contactField, ConstraintValidatorContext context) {
        // Default validity is true until proven otherwise.
        boolean valid = true;
        

        if ("".equalsIgnoreCase(contactField) || contactField == null  ) {
            valid = false;
            logger.debug("entered--1--");
            context.buildConstraintViolationWithTemplate(	
               "UserName cannot be blank").addConstraintViolation();
        }else if(contactField != null && contactField.matches("[0-9]+")){
        	 valid = false;
             logger.debug("entered- 2---");
             context.buildConstraintViolationWithTemplate(
                "UserName cannot have numbers").addConstraintViolation();
             
        }else if(contactField != null && ValidationUtil.validateRegex(".*\\W+.*", contactField)){
       	 valid = false;
         logger.debug("entered 3----");
         context.buildConstraintViolationWithTemplate(
            "UserName cannot have special characters").addConstraintViolation();
        
        }

        return valid;
    }
    
  
    

}
