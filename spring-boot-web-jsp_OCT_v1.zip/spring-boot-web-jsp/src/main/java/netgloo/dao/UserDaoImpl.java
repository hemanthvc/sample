package netgloo.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import com.mongodb.BasicDBObject;

import netgloo.config.GetMongoDBConnection;
import netgloo.config.SpringMongoConfig;
import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import netgloo.models.UserRoles;


@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	private static Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);
	
	String status = "FAIL";
	
	@Override
	public String saveUser(User user) {
		
		//new BCryptPasswordEncoder().encode(userBean.getPassword())
		
		//user.getPassword()
		user.setPassword1(new BCryptPasswordEncoder().encode(user.getPassword()));
		user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
		
		// TODO Auto-generated method stub
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		mongoOperation.save(user, "User");
		status = "PASS";
		
		return status;
	}

	@Override
	public List<netgloo.models.User> getUsers(String user) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		logger.debug("user :"+user);
		Query query4 = new Query();
		query4.addCriteria(Criteria.where("username").is(user));
		netgloo.models.User user1 = mongoOperation.findOne(query4, netgloo.models.User.class);
		List<netgloo.models.User> users = null;
		
		logger.debug("ROLE :"+user1.getRole());
		if(null != user1 && user1.getRole().equalsIgnoreCase("ADMIN")){
			 users = mongoOperation.findAll(netgloo.models.User.class);
		}else{
			netgloo.models.User user3 = mongoOperation.findOne(query4, netgloo.models.User.class);
			users = new ArrayList<netgloo.models.User>();
			users.add(user3);
		}
			

			
		logger.debug("Number of users = " + users.size());
		return users;
	}

	@Override
	public List<Country> getCountry() {

		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		List<Country> listCountry = mongoOperation.findAll(Country.class);
		logger.debug("Number of country = " + listCountry.size());
		return listCountry;
	}

	@Override
	public List<States> getStates(String country) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		Query query3 = new Query();
		query3.addCriteria(Criteria.where("country_id").is(country));

		logger.debug(query3.toString());
		List<States> states = new ArrayList<States>();
		states = mongoOperation.find(query3, States.class);

		logger.debug("Number of states = " + states.size());

		return states;
	}

	@Override
	public List<UserRoles> getUserRoles() {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		List<UserRoles> roles = mongoOperation.findAll(UserRoles.class);

		logger.debug("Number of roles = " + roles.size());
		return roles;
	}

	@Override
	public String validateUser(String username,String password) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		String result = "FAIL";
		
		Query query4 = new Query();
		query4.addCriteria(Criteria.where("username").is(username));
		netgloo.models.User user1 = mongoOperation.findOne(query4, netgloo.models.User.class);
		int passwordUpdate = Integer.parseInt(user1.getPasswordUpdate());
		String role="T";
		if(null != user1){
			String accountLocked = user1.getLocked();
			
			if("N".equalsIgnoreCase(accountLocked)){
				Query query3 = new Query();
				query3.addCriteria(Criteria.where("username").is(username).andOperator(Criteria.where("password"+passwordUpdate).is(password)));
		
				number_retry = number_retry + 1;
		
				netgloo.models.User user = mongoOperation.findOne(query3, netgloo.models.User.class);
		
				
				if (null != user){
					
					return "PASS-"+user.getRole();
				}else{
					
					if(number_retry > 5){
						user1.setLocked("Y");
						mongoOperation.save(user1);
						return "FAIL1-"+role;
					}else{
						return "FAIL2-"+role;
					}
					
				}
				
			}else{
				result = "FAIL1-"+role;
			}
		}

		logger.debug("Number of states = " + result);

		return result;
	}
	
	/*@Override
	public String validateUser(String username,String password) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		String result = "FAIL";
		Query query3 = new Query();
		query3.addCriteria(Criteria.where("username").is(username).andOperator(Criteria.where("password").is(password)));

		logger.debug(query3.toString());

		netgloo.models.User user = mongoOperation.findOne(query3, netgloo.models.User.class);

		if (null != user)
			result = "PASS";

		logger.debug("Number of states = " + result);

		return result;
	}*/

	@Override
	public List<netgloo.models.User> editUser(User user) {
		
		List<String> roleData = new ArrayList<String>();
		
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(user.getUsername()));
		logger.debug(query+"---"+user.getFirstname()+"----"+user.getUsername());
		netgloo.models.User userTest1 = mongoOperation.findOne(query, netgloo.models.User.class);
		userTest1.setFirstname(user.getFirstname());
		userTest1.setLastname(user.getLastname());
		//userTest1.setPassword(user.getPassword());
		userTest1.setEmail(user.getEmail());
		userTest1.setAddress(user.getAddress());
		userTest1.setPhone(user.getPhone());
		userTest1.setSecretQuestion(user.getSecretQuestion());
		userTest1.setSecretAnswer(user.getSecretAnswer());
		if(null != user.getRole()){
			roleData.add(user.getRole());
			userTest1.setAuthorities(roleData);
		}
		
		
		userTest1.setLocked(user.getLocked());
		
		mongoOperation.save(userTest1);

		//get the updated object again
		List<netgloo.models.User> users = mongoOperation.findAll(netgloo.models.User.class);
		
		return users;
	}
	
	@Override
	public netgloo.models.User getUser(User user) {
		
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(user.getUsername()));
		logger.debug(query.toString());
		netgloo.models.User userTest1 = mongoOperation.findOne(query, netgloo.models.User.class);
		return userTest1;
	}
	
	@Override
	public netgloo.models.User getUserLike(User user) {
		netgloo.models.User userTest1 = new netgloo.models.User();
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(user.getUsername()));
		
		userTest1 = mongoOperation.findOne(query, netgloo.models.User.class);
		if(null == userTest1){
			userTest1 = new netgloo.models.User();
			userTest1.setResult("NA");
		}else{
			userTest1.setResult("EXISTS");
		}
		
		return userTest1;
	}

	@Override
	public List<netgloo.models.User>  deleteUser(String username) {
		// TODO Auto-generated method stub
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(username));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		mongoOperation.remove(userTest2);
		
		//get the updated object again
		List<netgloo.models.User> users = mongoOperation.findAll(netgloo.models.User.class);

		
		return users;
	}

	@Override
	public netgloo.models.User getSecretQuestion(String userId) {
		netgloo.models.User userTest3 = new netgloo.models.User();
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(userId));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		logger.debug("getSecretQuestion DAO ----"+userId);
		if(null != userTest2 && null != userTest2.getUsername()){
			logger.debug("data : "+userTest2.getSecretQuestion());
			userTest3.setResult(userTest2.getSecretQuestion());
			return userTest3;
		}
		userTest3.setResult("FAIL");
		return userTest3;
	}
	
	@Override
	public netgloo.models.User validateSecretQuestion(String userId,String question) {
		netgloo.models.User userTest3 = new netgloo.models.User();
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		logger.debug(userId+"-------------"+question);
		query.addCriteria(Criteria.where("username").is(userId).and("secretAnswer").is(question));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		
		logger.debug("userTest2 :"+userTest2);
		logger.debug("validateSecretQuestion DAO ----"+userId);
		if(null != userTest2 && question.equalsIgnoreCase(userTest2.getSecretAnswer())){
			logger.debug("data : "+userTest2.getSecretQuestion());
			userTest3.setResult("SUCCESS");
			return userTest3;
		}
		userTest3.setResult("FAIL");
		return userTest3;
	}

	int number_retry = 0;
	
	@Override
	public netgloo.models.User resetPassword(String oldPassword, String password,String username) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		netgloo.models.User userTest3 = new netgloo.models.User();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(username));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		logger.debug("resetPassword DAO ----"+oldPassword);
		
		if(null != userTest2){
			
			
			String userLocked = userTest2.getLocked();
			
			
			if("N".equalsIgnoreCase(userLocked)){
				if(new BCryptPasswordEncoder().matches(password, userTest2.getPassword1()) || new BCryptPasswordEncoder().matches(password, userTest2.getPassword2())
						|| new BCryptPasswordEncoder().matches(password, userTest2.getPassword3()) || new BCryptPasswordEncoder().matches(password, userTest2.getPassword4()) 
						|| new BCryptPasswordEncoder().matches(password, userTest2.getPassword5())){
					
				/*}
				if(password.equalsIgnoreCase(userTest2.getPassword1()) || password.equalsIgnoreCase(userTest2.getPassword2()) || password.equalsIgnoreCase(userTest2.getPassword3())
						|| password.equalsIgnoreCase(userTest2.getPassword4()) || password.equalsIgnoreCase(userTest2.getPassword5())){*/
					
						userTest3.setResult("FAIL1");

					return userTest3;
				}else{
					int updatePassword = Integer.parseInt(userTest2.getPasswordUpdate());
					
					if(updatePassword == 1){
						userTest2.setPassword2(new BCryptPasswordEncoder().encode(password));
						userTest2.setPasswordUpdate("2");
				    } else if(updatePassword == 2){
				    	userTest2.setPassword3(new BCryptPasswordEncoder().encode(password));
						userTest2.setPasswordUpdate("3");
				    }else if(updatePassword == 3){
				    	userTest2.setPassword4(new BCryptPasswordEncoder().encode(password));
						userTest2.setPasswordUpdate("4");
				    }else if(updatePassword == 4){
				    	userTest2.setPassword5(new BCryptPasswordEncoder().encode(password));
						userTest2.setPasswordUpdate("5");
				    }else{
				    	userTest2.setPassword1(new BCryptPasswordEncoder().encode(password));
						userTest2.setPasswordUpdate("1");
				    }
				
					userTest2.setUsername(username);
					userTest2.setPassword(new BCryptPasswordEncoder().encode(password));
					mongoOperation.save(userTest2);
				
					userTest3.setResult("SUCCESS");
					return userTest3;
				}
			}else{
				userTest3.setResult("FAIL2");
				return userTest3;
			}
			
		}
		userTest3.setResult("FAIL");
		return userTest3;
	}

	@Override
	public List<netgloo.models.User> getUserOnSearch(String user) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		String colName="username";
		logger.debug("getUserOnSearch Impl :"+user);
		Query query4 = new Query();
		
		if(null != user && StringUtils.isNumeric(user))
			colName = "phone";
		
		query4.addCriteria(Criteria.where(colName).regex(user));
		List<netgloo.models.User> user1 = mongoOperation.find(query4, netgloo.models.User.class);
				

			
		logger.debug("Number of users = " + user1.size());
		return user1;
	}

	@Override
	public String changePassword(String oldPassword, String newpassword, String username) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		netgloo.models.User userTest3 = new netgloo.models.User();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(username));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		logger.debug("resetPassword DAO ----"+oldPassword);
		
		if(null != userTest2){
			
			String userLocked = userTest2.getLocked();
			
			if(oldPassword.equalsIgnoreCase(newpassword))
				return "SAMEPWD";
			
			
			
			if("N".equalsIgnoreCase(userLocked)){
				
				int updatePassword = Integer.parseInt(userTest2.getPasswordUpdate());
				
				
				
				String oldPasswordDb= userTest2.getPassword();
				
				if(!new BCryptPasswordEncoder().matches(oldPassword, oldPasswordDb)){
				//if(!oldPassword.equalsIgnoreCase(oldPasswordDb)){
					return "OLDNEWNOTMATCH";
				}
				
				else if(new BCryptPasswordEncoder().matches(newpassword, userTest2.getPassword1()) || new BCryptPasswordEncoder().matches(newpassword, userTest2.getPassword2())
						|| new BCryptPasswordEncoder().matches(newpassword, userTest2.getPassword3()) || new BCryptPasswordEncoder().matches(newpassword, userTest2.getPassword4()) 
						|| new BCryptPasswordEncoder().matches(newpassword, userTest2.getPassword5())){
				
				/*else if(newpassword.equalsIgnoreCase(userTest2.getPassword1()) || newpassword.equalsIgnoreCase(userTest2.getPassword2()) || newpassword.equalsIgnoreCase(userTest2.getPassword3())
						|| newpassword.equalsIgnoreCase(userTest2.getPassword4()) || newpassword.equalsIgnoreCase(userTest2.getPassword5())){*/
					return "PRVPWDSAME";
				}else{
					//int updatePassword = Integer.parseInt(userTest2.getPasswordUpdate());
					
					if(updatePassword == 1){
						userTest2.setPassword2(new BCryptPasswordEncoder().encode(newpassword));
						userTest2.setPasswordUpdate("2");
				    } else if(updatePassword == 2){
				    	userTest2.setPassword3(new BCryptPasswordEncoder().encode(newpassword));
						userTest2.setPasswordUpdate("3");
				    }else if(updatePassword == 3){
				    	userTest2.setPassword4(new BCryptPasswordEncoder().encode(newpassword));
						userTest2.setPasswordUpdate("4");
				    }else if(updatePassword == 4){
				    	userTest2.setPassword5(new BCryptPasswordEncoder().encode(newpassword));
						userTest2.setPasswordUpdate("5");
				    }else{
				    	userTest2.setPassword1(new BCryptPasswordEncoder().encode(newpassword));
						userTest2.setPasswordUpdate("1");
				    }
					userTest2.setUsername(username);
					userTest2.setPassword(new BCryptPasswordEncoder().encode(newpassword));
					mongoOperation.save(userTest2);
					return "SUCCESS";
				}
			}else{
				return "LOCKED";
			}
			
		}
		return "FAIL";
	}
	
	public Map<String,String> getGroupByUser() {

		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		
		List<netgloo.models.Country> country = mongoOperation.findAll(netgloo.models.Country.class);
		Map<String,String> dataMap =new HashMap<String, String>();	
		
		if(null != country){
			
			for(Country cnty : country){
				Query query = new Query();
				logger.debug("getGroupByUser : "+cnty.getCountry_id());
				 		
				query.addCriteria(Criteria.where("country").is(cnty.getCountry_id()));
				
				List<netgloo.models.User> user1 = mongoOperation.find(query, netgloo.models.User.class);
				
				logger.debug("size :"+user1.size());
				if(null != user1)
					dataMap.put(cnty.getCountry_name(),String.valueOf(user1.size()));
			}
		}
		
		
			 
		return dataMap;

	}
}
