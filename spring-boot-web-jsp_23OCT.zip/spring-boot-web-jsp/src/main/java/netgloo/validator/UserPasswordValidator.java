package netgloo.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import netgloo.contraint.PasswordConstraint;

public class UserPasswordValidator implements
  ConstraintValidator<PasswordConstraint, String> {
 
	private static Logger logger = LoggerFactory.getLogger(UserPasswordValidator.class);
	
    @Override
    public void initialize(PasswordConstraint contactNumber) {
    	
    }
 
    @Override
    public boolean isValid(String contactField,
      ConstraintValidatorContext cxt) {
    	logger.debug("*********isValid*********"+contactField);
    	cxt.disableDefaultConstraintViolation();
    	
    	
        return checkConstraint1(contactField,cxt);
    }
    
 // Note: A private method for each constraint decreases the cyclomatic complexity.
    private boolean checkConstraint1(String contactField, ConstraintValidatorContext context) {
        // Default validity is true until proven otherwise.
        boolean valid = true;
        

        if ("".equalsIgnoreCase(contactField) || contactField == null  ) {
            valid = false;
            logger.debug("entered--1--");
            context.buildConstraintViolationWithTemplate(	
               "Password cannot be blank").addConstraintViolation();
        }else if(contactField != null && contactField.length() < 8){
       	 valid = false;
         logger.debug("entered 3----");
         context.buildConstraintViolationWithTemplate(
            "Password should contain atleast 8 characters").addConstraintViolation();
        
        }

        return valid;
    }
    
  
    

}
