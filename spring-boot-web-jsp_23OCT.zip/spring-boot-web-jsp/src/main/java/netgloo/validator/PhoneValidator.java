package netgloo.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import netgloo.contraint.*;
import netgloo.util.ValidationUtil;

public class PhoneValidator implements
  ConstraintValidator<PhoneConstraint, String> {
 
	private static Logger logger = LoggerFactory.getLogger(PhoneValidator.class);
	
    @Override
    public void initialize(PhoneConstraint contactNumber) {
    	
    }
 
    @Override
    public boolean isValid(String contactField,
      ConstraintValidatorContext cxt) {
    	logger.debug("*********isValid*********"+contactField);
    	cxt.disableDefaultConstraintViolation();
    	
    	
        return checkConstraint1(contactField,cxt);
    }
    
 // Note: A private method for each constraint decreases the cyclomatic complexity.
    private boolean checkConstraint1(String contactField, ConstraintValidatorContext context) {
        // Default validity is true until proven otherwise.
        boolean valid = true;
        

        if ("".equalsIgnoreCase(contactField) || contactField == null  ) {
            valid = false;
            logger.debug("entered--1--");
            context.buildConstraintViolationWithTemplate(	
               "Phone Number cannot be blank").addConstraintViolation();
        }else if(contactField != null && !ValidationUtil.validateRegex("\\d{10}", contactField)){
       	 valid = false;
         logger.debug("entered 3----");
         context.buildConstraintViolationWithTemplate(
            "Phone Number should have only number and 10 digits.").addConstraintViolation();
        
        }

        return valid;
    }
    
  
    

}
