package netgloo.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import netgloo.contraint.NameConstraint;
import netgloo.contraint.PasswordConstraint;
import netgloo.util.ValidationUtil;

public class NameValidator implements
  ConstraintValidator<NameConstraint, String> {
 
	private static Logger logger = LoggerFactory.getLogger(NameValidator.class);
	
    @Override
    public void initialize(NameConstraint contactNumber) {
    	
    }
 
    @Override
    public boolean isValid(String contactField,
      ConstraintValidatorContext cxt) {
    	logger.debug("*********isValid*********"+contactField);
    	cxt.disableDefaultConstraintViolation();
    	
    	
        return checkConstraint1(contactField,cxt);
    }
    
 // Note: A private method for each constraint decreases the cyclomatic complexity.
    private boolean checkConstraint1(String contactField, ConstraintValidatorContext context) {
        // Default validity is true until proven otherwise.
        boolean valid = true;
        

        if ("".equalsIgnoreCase(contactField) || contactField == null  ) {
            valid = false;
            logger.debug("entered--1--");
            context.buildConstraintViolationWithTemplate(	
               "FirstName cannot be blank").addConstraintViolation();
        }else if(contactField != null && ValidationUtil.validateRegex("[^A-Za-z]", contactField)){
       	 valid = false;
         logger.debug("entered 3----");
         context.buildConstraintViolationWithTemplate(
            "FirstName can have only letters.").addConstraintViolation();
        
        }

        return valid;
    }
    
  
    

}
