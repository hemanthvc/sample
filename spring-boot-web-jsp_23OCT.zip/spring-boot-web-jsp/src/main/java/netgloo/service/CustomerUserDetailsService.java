package netgloo.service;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import netgloo.models.MongoUserDetails;
/**
 * Created by gkatzioura on 9/27/16.
 */

@Service("userDetailsService")
public class CustomerUserDetailsService implements UserDetailsService {
    @Autowired
    private MongoClient mongoClient;
    
    
    
    private static Logger logger = LoggerFactory.getLogger(CustomerUserDetailsService.class);
    
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        MongoDatabase database = mongoClient.getDatabase("local");
       
       
       /* MongoIterable<String> allCollections=database.listCollectionNames();
        for (    String collection : allCollections) {
          System.out.println(collection);
        }*/
       
        
        MongoCollection<Document> collection = database.getCollection("User");
      
        Document document = collection.find(Filters.eq("username",username)).first();
        if(document!=null) {
        	logger.debug("loadUserByUsername document is not null.....");
        	
        	if("Y".equalsIgnoreCase(document.getString("locked")))
        			throw new UsernameNotFoundException("AccountLocked");
        	
            String name = document.getString("username");
            String password = document.getString("password");
            String authoritiesTmp = String.valueOf(document.get("authorities"));
            
            List<String> data  = new ArrayList<String>();
            data.add(authoritiesTmp);
           
 
            
            List<String> authorities = data;
            MongoUserDetails mongoUserDetails = new MongoUserDetails(username,password,authorities.toArray(new String[authorities.size()]));
            
            
            return mongoUserDetails;
        }
        
        
        
        logger.debug("loadUserByUsername document is  null.....");
        return null;
    }
}