package netgloo.dao;

import java.util.List;
import java.util.Map;

import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import netgloo.models.UserRoles;

public interface UserDao {
	String saveUser(User user);

	//List<User> getAllAccountDetails();

	//void updateAccountDetails(String userId);

	//void updateAccountDetailsByName(String name);

	//String deleteAccount(String userId);
	
	List<netgloo.models.User> getUsers(String user);
	
	List<Country> getCountry();
	
	Map<String,String> getGroupByUser();
	
	netgloo.models.User getUserLike(User user);
	
	List<States> getStates(String country);
	
	List<netgloo.models.User> getUserOnSearch(String user);
	
	List<UserRoles> getUserRoles();
	
	String validateUser(String username,String password);
	
	List<netgloo.models.User> editUser(User user);
	
	List<netgloo.models.User> deleteUser(String username);
	
	netgloo.models.User getUser(User user);
	
	netgloo.models.User getSecretQuestion(String userId);
	
	netgloo.models.User resetPassword(String olspassword,String password,String username);
	
	netgloo.models.User validateSecretQuestion(String userId,String question);
	
	
	String changePassword(String oldpassword,String newpassword,String username);
	

}