package netgloo.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import netgloo.contraint.*;
import netgloo.util.ValidationUtil;

public class PhoneValidator implements
  ConstraintValidator<PhoneConstraint, String> {
 
    @Override
    public void initialize(PhoneConstraint contactNumber) {
    	
    }
 
    @Override
    public boolean isValid(String contactField,
      ConstraintValidatorContext cxt) {
    	System.out.println("*********isValid*********"+contactField);
    	cxt.disableDefaultConstraintViolation();
    	
    	
        return checkConstraint1(contactField,cxt);
    }
    
 // Note: A private method for each constraint decreases the cyclomatic complexity.
    private boolean checkConstraint1(String contactField, ConstraintValidatorContext context) {
        // Default validity is true until proven otherwise.
        boolean valid = true;
        

        if ("".equalsIgnoreCase(contactField) || contactField == null  ) {
            valid = false;
            System.out.println("entered--1--");
            context.buildConstraintViolationWithTemplate(	
               "Phone Number cannot be blank").addConstraintViolation();
        }else if(contactField != null && !ValidationUtil.validateRegex("\\d{10}", contactField)){
       	 valid = false;
         System.out.println("entered 3----");
         context.buildConstraintViolationWithTemplate(
            "Phone Number should have only number and 10 digits.").addConstraintViolation();
        
        }

        return valid;
    }
    
  
    

}
