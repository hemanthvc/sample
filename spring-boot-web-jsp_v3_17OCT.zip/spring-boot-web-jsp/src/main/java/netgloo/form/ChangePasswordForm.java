package netgloo.form;

import netgloo.contraint.PasswordConstraint;

public class ChangePasswordForm {
	@PasswordConstraint
	String oldPassword;
	
	@PasswordConstraint
	String newPassword;
	
	String userName;
	
	String result;
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
}
