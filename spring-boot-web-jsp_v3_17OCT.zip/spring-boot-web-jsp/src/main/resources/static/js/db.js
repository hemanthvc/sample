(function() {

    var db = {

        loadData: function(filter) {
            return $.grep(this.clients, function(client) {
                return (!filter.username || client.username.indexOf(filter.username) > -1)
                   // && (filter.email === undefined || client.Age === filter.Age)
                    && (!filter.email || client.email.indexOf(filter.email) > -1)
                     && (!filter.address || client.Address.indexOf(filter.address) > -1);
                    //&& (filter.Married === undefined || client.Married === filter.Married);
            });
        },

        insertItem: function(insertingClient) {
            this.clients.push(insertingClient);
        },

        updateItem: function(updatingClient) { },

        deleteItem: function(deletingClient) {
            var clientIndex = $.inArray(deletingClient, this.clients);
            this.clients.splice(clientIndex, 1);
        }

    };

    window.db = db;


    db.countries = [
        { Name: "", Id: 0 },
        { Name: "United States", Id: 1 },
        { Name: "Canada", Id: 2 },
        { Name: "United Kingdom", Id: 3 },
        { Name: "France", Id: 4 },
        { Name: "Brazil", Id: 5 },
        { Name: "China", Id: 6 },
        { Name: "Russia", Id: 7 }
    ];

    db.clients = [
    	{
    	    "locked" : "N",
    	    "username" : "admin",
    	    "password1" : "admin5",
    	    "password2" : "admin",
    	    "password3" : "admin2",
    	    "password4" : "admin3",
    	    "password5" : "admin4",
    	    "passwordUpdate" : "2",
    	    "email" : "123",
    	    "country" : "IND",
    	    "state" : "KRN",
    	    "firstname" : "Hemantha",
    	    "lastname" : "kumar",
    	    "address" : "qwe",
    	    "role" : "ADMIN",
    	    "phone" : "23213",
    	    "secretQuestion" : "Your favorite place",
    	    "secretAnswer" : "banglore1"
    	},
    	{
    	    "locked" : "N",
    	    "username" : "admin",
    	    "password1" : "admin5",
    	    "password2" : "admin",
    	    "password3" : "admin2",
    	    "password4" : "admin3",
    	    "password5" : "admin4",
    	    "passwordUpdate" : "2",
    	    "email" : "123",
    	    "country" : "IND",
    	    "state" : "KRN",
    	    "firstname" : "Hemantha",
    	    "lastname" : "kumar",
    	    "address" : "qwe",
    	    "role" : "ADMIN",
    	    "phone" : "23213",
    	    "secretQuestion" : "Your favorite place",
    	    "secretAnswer" : "banglore1"
    	}
    ];

   

}());