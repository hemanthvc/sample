package netgloo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import netgloo.config.GetMongoDBConnection;
import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import netgloo.models.UserRoles;


@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	String status = "FAIL";
	
	@Override
	public String saveUser(User user) {
		
		
		// TODO Auto-generated method stub
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		mongoOperation.save(user, "User");
		status = "PASS";
		
		return status;
	}

	@Override
	public List<netgloo.models.User> getUsers(String user) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		System.out.println("user :"+user);
		Query query4 = new Query();
		query4.addCriteria(Criteria.where("username").is(user));
		netgloo.models.User user1 = mongoOperation.findOne(query4, netgloo.models.User.class);
		List<netgloo.models.User> users = null;
		
		System.out.println("ROLE :"+user1.getRole());
		if(null != user1 && user1.getRole().equalsIgnoreCase("ADMIN")){
			 users = mongoOperation.findAll(netgloo.models.User.class);
		}else{
			netgloo.models.User user3 = mongoOperation.findOne(query4, netgloo.models.User.class);
			users = new ArrayList<netgloo.models.User>();
			users.add(user3);
		}
			

			
		System.out.println("Number of users = " + users.size());
		return users;
	}

	@Override
	public List<Country> getCountry() {

		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		List<Country> listCountry = mongoOperation.findAll(Country.class);
		System.out.println("Number of country = " + listCountry.size());
		return listCountry;
	}

	@Override
	public List<States> getStates(String country) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		Query query3 = new Query();
		query3.addCriteria(Criteria.where("country_id").is(country));

		System.out.println(query3.toString());
		List<States> states = new ArrayList<States>();
		states = mongoOperation.find(query3, States.class);

		System.out.println("Number of states = " + states.size());

		return states;
	}

	@Override
	public List<UserRoles> getUserRoles() {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		List<UserRoles> roles = mongoOperation.findAll(UserRoles.class);

		System.out.println("Number of roles = " + roles.size());
		return roles;
	}

	@Override
	public String validateUser(String username,String password) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		String result = "FAIL";
		
		Query query4 = new Query();
		query4.addCriteria(Criteria.where("username").is(username));
		netgloo.models.User user1 = mongoOperation.findOne(query4, netgloo.models.User.class);
		int passwordUpdate = Integer.parseInt(user1.getPasswordUpdate());
		
		if(null != user1){
			String accountLocked = user1.getLocked();
			
			if("N".equalsIgnoreCase(accountLocked)){
				Query query3 = new Query();
				query3.addCriteria(Criteria.where("username").is(username).andOperator(Criteria.where("password"+passwordUpdate).is(password)));
		
				System.out.println(query3.toString());
		
				netgloo.models.User user = mongoOperation.findOne(query3, netgloo.models.User.class);
		
				
				if (null != user)
					result = "PASS";
			
			}else{
				result = "FAIL1";
			}
		}

		System.out.println("Number of states = " + result);

		return result;
	}
	
	/*@Override
	public String validateUser(String username,String password) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		String result = "FAIL";
		Query query3 = new Query();
		query3.addCriteria(Criteria.where("username").is(username).andOperator(Criteria.where("password").is(password)));

		System.out.println(query3.toString());

		netgloo.models.User user = mongoOperation.findOne(query3, netgloo.models.User.class);

		if (null != user)
			result = "PASS";

		System.out.println("Number of states = " + result);

		return result;
	}*/

	@Override
	public List<netgloo.models.User> editUser(User user) {
		
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(user.getUsername()));
		System.out.println(query+"---"+user.getFirstname()+"----"+user.getUsername());
		netgloo.models.User userTest1 = mongoOperation.findOne(query, netgloo.models.User.class);
		userTest1.setFirstname(user.getFirstname());
		userTest1.setLastname(user.getLastname());
		//userTest1.setPassword(user.getPassword());
		userTest1.setEmail(user.getEmail());
		userTest1.setAddress(user.getAddress());
		userTest1.setPhone(user.getPhone());
		userTest1.setSecretQuestion(user.getSecretQuestion());
		userTest1.setSecretAnswer(user.getSecretAnswer());
		userTest1.setRole(user.getRole());
		
		mongoOperation.save(userTest1);

		//get the updated object again
		List<netgloo.models.User> users = mongoOperation.findAll(netgloo.models.User.class);
		
		return users;
	}
	
	@Override
	public netgloo.models.User getUser(User user) {
		
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(user.getUsername()));
		System.out.println(query);
		netgloo.models.User userTest1 = mongoOperation.findOne(query, netgloo.models.User.class);
		return userTest1;
	}
	
	@Override
	public netgloo.models.User getUserLike(User user) {
		netgloo.models.User userTest1 = new netgloo.models.User();
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(user.getUsername()));
		
		userTest1 = mongoOperation.findOne(query, netgloo.models.User.class);
		if(null == userTest1){
			userTest1 = new netgloo.models.User();
			userTest1.setResult("NA");
		}else{
			userTest1.setResult("EXISTS");
		}
		
		return userTest1;
	}

	@Override
	public List<netgloo.models.User>  deleteUser(String username) {
		// TODO Auto-generated method stub
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(username));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		mongoOperation.remove(userTest2);
		
		//get the updated object again
		List<netgloo.models.User> users = mongoOperation.findAll(netgloo.models.User.class);

		
		return users;
	}

	@Override
	public netgloo.models.User getSecretQuestion(String userId) {
		netgloo.models.User userTest3 = new netgloo.models.User();
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(userId));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		System.out.println("getSecretQuestion DAO ----"+userId);
		if(null != userTest2 && null != userTest2.getUsername()){
			System.out.println("data : "+userTest2.getSecretQuestion());
			userTest3.setResult(userTest2.getSecretQuestion());
			return userTest3;
		}
		userTest3.setResult("FAIL");
		return userTest3;
	}
	
	@Override
	public netgloo.models.User validateSecretQuestion(String userId,String question) {
		netgloo.models.User userTest3 = new netgloo.models.User();
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		System.out.println(userId+"-------------"+question);
		query.addCriteria(Criteria.where("username").is(userId).and("secretAnswer").is(question));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		
		System.out.println("userTest2 :"+userTest2);
		System.out.println("validateSecretQuestion DAO ----"+userId);
		if(null != userTest2 && question.equalsIgnoreCase(userTest2.getSecretAnswer())){
			System.out.println("data : "+userTest2.getSecretQuestion());
			userTest3.setResult("SUCCESS");
			return userTest3;
		}
		userTest3.setResult("FAIL");
		return userTest3;
	}

	int number_retry = 0;
	
	@Override
	public netgloo.models.User resetPassword(String oldPassword, String password,String username) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		netgloo.models.User userTest3 = new netgloo.models.User();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(username));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		System.out.println("resetPassword DAO ----"+oldPassword);
		
		if(null != userTest2){
			
			
			if(password.equalsIgnoreCase(userTest2.getPassword1()) || password.equalsIgnoreCase(userTest2.getPassword2()) || password.equalsIgnoreCase(userTest2.getPassword3())
					|| password.equalsIgnoreCase(userTest2.getPassword4()) || password.equalsIgnoreCase(userTest2.getPassword5())){
				
				number_retry = number_retry + 1;
				
				if(number_retry > 5){
					userTest3.setResult("FAIL2");
					userTest2.setLocked("Y");
					mongoOperation.save(userTest2);
				}else{
					userTest3.setResult("FAIL1");
				}
				return userTest3;
			}
			
			int updatePassword = Integer.parseInt(userTest2.getPasswordUpdate());
			
			if(updatePassword == 1){
				userTest2.setPassword2(password);
				userTest2.setPasswordUpdate("2");
		    } else if(updatePassword == 2){
		    	userTest2.setPassword3(password);
				userTest2.setPasswordUpdate("3");
		    }else if(updatePassword == 3){
		    	userTest2.setPassword4(password);
				userTest2.setPasswordUpdate("4");
		    }else if(updatePassword == 4){
		    	userTest2.setPassword5(password);
				userTest2.setPasswordUpdate("5");
		    }else{
		    	userTest2.setPassword1(password);
				userTest2.setPasswordUpdate("1");
		    }
		
			userTest2.setUsername(username);
			mongoOperation.save(userTest2);
		
			userTest3.setResult("SUCCESS");
			return userTest3;
		}
		userTest3.setResult("FAIL");
		return userTest3;
	}
}
