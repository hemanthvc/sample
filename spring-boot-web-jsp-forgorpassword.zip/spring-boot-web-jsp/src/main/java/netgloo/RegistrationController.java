package netgloo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import netgloo.models.UserRoles;
import netgloo.service.UserService;

@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
public class RegistrationController {

	@Autowired
	public UserService userService;

	@PostMapping("/createUser")
	public ResponseEntity<?> createUser(@RequestBody User user) {
		System.out.println("Creating User " + user.getUsername());
		String result = "success";
		//user.setRole("us");
		userService.saveUser(user);
		return ResponseEntity.ok(result);
	}

	@PostMapping("/state")
	public ResponseEntity<?> getState(@RequestBody User user) {
		System.out.println("in State function " + user.getCountry());
		List<States> state = new ArrayList<States>();

		System.out.println("size---" + state.size());

		state = userService.getStates(user.getCountry());

		return ResponseEntity.ok(state);
	}

	@PostMapping("/country")
	public ResponseEntity<List<Country>> getCountry(@RequestBody User user) {
		System.out.println("in getCountry function " + user.getCountry());

		List<Country> country = new ArrayList<Country>();
		country = userService.getCountry();

		return ResponseEntity.ok(country);
	}

	@PostMapping("/users")
	public ResponseEntity<List<netgloo.models.User>> getUsers(@RequestBody User user) {
		System.out.println("in getUsers function " + user.getCountry());

		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userService.getUsers();

		return ResponseEntity.ok(users);
	}

	@PostMapping("/roles")
	public ResponseEntity<List<UserRoles>> getUserRoles(@RequestBody User user) {
		System.out.println("in getUsers function " + user.getCountry());

		List<UserRoles> roles = new ArrayList<UserRoles>();
		roles = userService.getUserRoles();

		return ResponseEntity.ok(roles);
	}

	@PostMapping("/login")
	public ResponseEntity<?> validateUser(@RequestBody User user) {
		System.out.println("in validateUser function " + user.getUsername());
		User user1 = new User();
		String result = userService.validateUser(user.getUsername(),user.getPassword());
		user1.setLastname(result);

		return ResponseEntity.ok(user1);
	}
	
	@PostMapping("/editUser")
	public ResponseEntity<List<netgloo.models.User>> editUser(@RequestBody User user) {
		System.out.println("in editUser function " + user.getUsername());
	
		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userService.editUser(user);
		

		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/deleteUser")
	public ResponseEntity<List<netgloo.models.User>> deleteUser(@RequestBody User user) {
		System.out.println("in deleteUser function " + user.getUsername());
		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userService.deleteUser(user.getUsername());
		

		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/getUser")
	public ResponseEntity<netgloo.models.User> getUser(@RequestBody User user) {
		System.out.println("in editUser function " + user.getUsername());
	
		netgloo.models.User users = new netgloo.models.User();
		users = userService.getUser(user);
		

		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/getSecretQuestion")
	public ResponseEntity<netgloo.models.User> getSecretQuestion(@RequestBody User user) {
		System.out.println("in getSecretQuestion function " + user.getUsername());
		netgloo.models.User users = new netgloo.models.User();
		users   = userService.getSecretQuestion(user.getUsername());
		
		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/validateSecretAnswer")
	public ResponseEntity<?> validateSecretAnswer(@RequestBody User user) {
		System.out.println(user.getUsername()+"--in validateSecretAnswer function " + user.getSecretAnswer());
		netgloo.models.User users = new netgloo.models.User();
		users  = userService.validateSecretQuestion(user.getUsername(),user.getSecretAnswer());
	
		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/resetPassword")
	public ResponseEntity<?> resetPassword(@RequestBody User user) {
		System.out.println(user.getUsername()+"--in resetPassword function " + user.getPassword()+"---"+user.getNewpassword());
		netgloo.models.User users = new netgloo.models.User();
		users  = userService.resetPassword(user.getPassword(),user.getNewpassword(),user.getUsername());
	
		return ResponseEntity.ok(users);
	}

}