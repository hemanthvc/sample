package netgloo;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import netgloo.form.User;

@Controller
public class WelcomeController {

	// inject via application.properties
	@Value("${welcome.message:test}")
	private String message = "Hello World";

	@RequestMapping("/")
	public String welcome(Map<String, Object> model) {
		System.out.println("*******************WelcomeController *************************");
		model.put("message", this.message);
		return "login";
	}
	

	@RequestMapping("/register")
	public ModelAndView index(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("register");
		mav.addObject("user", new User());

		return mav;
	}

	@RequestMapping("/about")
	public String about(Map<String, Object> model) {
		model.put("message", this.message);
		return "about";
	}

	@RequestMapping("/login")
	public String login(Map<String, Object> model) {
		model.put("message", this.message);
		return "login";
	}

	@RequestMapping("/403")
	public String error403() {
		return "403";
	}
	
	@RequestMapping("/forgotpassword")
	public ModelAndView forgotpassword(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("forgotpassword");
		mav.addObject("user", new User());

		return mav;
	}

}