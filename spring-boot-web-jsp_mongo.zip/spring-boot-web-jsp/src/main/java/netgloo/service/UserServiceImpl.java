package netgloo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import netgloo.dao.UserDao;
import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	@Override
	public void saveUser(User user) {
		userDao.saveUser(user);
	}

	@Override
	public List<User> getAllAccountDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateAccountDetails(String userId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAccountDetailsByName(String name) {
		// TODO Auto-generated method stub

	}

	@Override
	public String deleteAccount(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<netgloo.models.User> getUsers() {
		// TODO Auto-generated method stub
		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userDao.getUsers();
		return users;
	}

	@Override
	public List<Country> getCountry() {
		// TODO Auto-generated method stub
		List<Country> country = new ArrayList<Country>();
		country = userDao.getCountry();
		return country;
	}

	@Override
	public List<States> getStates(String country) {
		// TODO Auto-generated method stub
		List<States> states = new ArrayList<States>();
		states = userDao.getStates(country);
		return states;
	}

}
