package netgloo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import netgloo.service.UserService;

@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
public class RegistrationController {

	@Autowired
	public UserService userService;

	@PostMapping("/createUser")
	public ResponseEntity<?> createUser(@RequestBody User user) {
		System.out.println("Creating User " + user.getUsername());
		String result = "success";
		userService.saveUser(user);
		return ResponseEntity.ok(result);
	}

	@PostMapping("/state")
	public ResponseEntity<?> getState(@RequestBody User user) {
		System.out.println("in State function " + user.getCountry());
		List<States> state = new ArrayList<States>();

		System.out.println("size---"+state.size());
		
		state = userService.getStates(user.getCountry());

		return ResponseEntity.ok(state);
	}

	@PostMapping("/country")
	public ResponseEntity<List<Country>> getCountry(@RequestBody User user) {
		System.out.println("in getCountry function " + user.getCountry());

		List<Country> country = new ArrayList<Country>();
		country = userService.getCountry();

		return ResponseEntity.ok(country);
	}
	
	@PostMapping("/users")
	public ResponseEntity<List<netgloo.models.User>> getUsers(@RequestBody User user) {
		System.out.println("in getUsers function " + user.getCountry());

		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userService.getUsers();

		return ResponseEntity.ok(users);
	}

}