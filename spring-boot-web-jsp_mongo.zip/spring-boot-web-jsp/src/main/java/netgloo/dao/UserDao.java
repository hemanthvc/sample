package netgloo.dao;

import java.util.List;

import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;

public interface UserDao {
	void saveUser(User user);

	//List<User> getAllAccountDetails();

	//void updateAccountDetails(String userId);

	//void updateAccountDetailsByName(String name);

	//String deleteAccount(String userId);
	
	List<netgloo.models.User> getUsers();
	
	List<Country> getCountry();
	
	List<States> getStates(String country);
	
	

}