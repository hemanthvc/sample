package netgloo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Repository;

import netgloo.config.GetMongoDBConnection;
import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	@Override
	public void saveUser(User user) {
		// TODO Auto-generated method stub
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		mongoOperation.save(user, "User");
	}

	@Override
	public List<netgloo.models.User> getUsers() {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		List<netgloo.models.User> users = mongoOperation.findAll(netgloo.models.User.class);
		
		
		System.out.println("Number of users = " + users.size());
		return users;
	}

	@Override
	public List<Country> getCountry() {

		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		List<Country> listCountry = mongoOperation.findAll(Country.class);
		System.out.println("Number of country = " + listCountry.size());
		return listCountry;
	}

	@Override
	public List<States> getStates(String country) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		Query query3 = new Query();
		query3.addCriteria(Criteria.where("country_id").is(country));

		System.out.println(query3.toString());
		List<States> states = new ArrayList<States>();
		states = mongoOperation.find(query3, States.class);

		System.out.println("Number of states = " + states.size());

		return states;
	}

	/*
	 * @Override public List<User> getAllAccountDetails() { // TODO
	 * Auto-generated method stub return null; }
	 * 
	 * @Override public void updateAccountDetails(String userId) { // TODO
	 * Auto-generated method stub
	 * 
	 * }
	 * 
	 * @Override public void updateAccountDetailsByName(String name) { // TODO
	 * Auto-generated method stub
	 * 
	 * }
	 * 
	 * @Override public String deleteAccount(String userId) { // TODO
	 * Auto-generated method stub return null; }
	 */
}
// class UserMapper implements RowMapper<User> {
// public User mapRow(ResultSet rs, int arg1) throws SQLException {
// User user = new User();
// user.setUsername(rs.getString("username"));
// user.setPassword(rs.getString("password"));
// user.setFirstname(rs.getString("firstname"));
// user.setLastname(rs.getString("lastname"));
// user.setEmail(rs.getString("email"));
// user.setAddress(rs.getString("address"));
// user.setPhone(rs.getInt("phone"));
// return user;
// }
