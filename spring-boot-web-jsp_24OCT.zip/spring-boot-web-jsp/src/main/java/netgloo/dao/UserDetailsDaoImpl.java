package netgloo.dao;

import java.util.Date;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.authentication.LockedException;
import org.springframework.stereotype.Repository;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import netgloo.config.GetMongoDBConnection;
import netgloo.models.UserAttempts;

@Repository
public class UserDetailsDaoImpl  implements UserDetailsDAO {

	private static Logger logger = LoggerFactory.getLogger(UserDetailsDaoImpl.class);

	private static final int MAX_ATTEMPTS = 3;

	@Autowired
	private MongoOperations mongoOperation;

	@Autowired
	private MongoClient mongoClient;

	@Override
	public void updateFailAttempts(String username) {
		  UserAttempts user = getUserAttempts(username);
		  if (user == null) {
			if (isUserExists(username)) {
				// if no record, insert a new
				
			}
		  } else {

			if (isUserExists(username)) {
				MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

				Query query4 = new Query();
				query4.addCriteria(Criteria.where("username").is(username));
				netgloo.models.UserAttempts user1 = mongoOperation.findOne(query4, netgloo.models.UserAttempts.class);
				
				user1.setAttempts(1);
				mongoOperation.save(user1);
				
			}

			if (user.getAttempts() + 1 >= MAX_ATTEMPTS) {
				MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

				Query query4 = new Query();
				query4.addCriteria(Criteria.where("username").is(username));
				netgloo.models.User user1 = mongoOperation.findOne(query4, netgloo.models.User.class);
				
				user1.setLocked("Y");
				mongoOperation.save(user1);
				// throw exception
				throw new LockedException("User Account is locked!");
			}

		  }

	}

	@Override
	public void resetFailAttempts(String username) {

		
	}

	@Override
	public UserAttempts getUserAttempts(String username) {

		try {

			MongoDatabase database = mongoClient.getDatabase("local");

			MongoCollection<Document> collection = database.getCollection("UserAttempts");

			Document document = collection.find(Filters.eq("username", username)).first();

			if (null != document) {
				UserAttempts user = new UserAttempts();
				// user.setId(document.getString("id"));
				user.setUsername(String.valueOf(document.getString("username")));
				user.setAttempts(Integer.valueOf(document.getString("attempts")));
				user.setLastModified(new Date());

				return user;

			}

		} catch (Exception e) {
			return null;
		}
		return null;
	}

	private boolean isUserExists(String username) {

		boolean result = false;

		MongoDatabase database = mongoClient.getDatabase("local");

		MongoCollection<Document> collection = database.getCollection("UserAttempts");

		Document document = collection.find(Filters.eq("username", username)).first();

		if (null != document) {
			result = true;
		}

		return result;
	}

}
