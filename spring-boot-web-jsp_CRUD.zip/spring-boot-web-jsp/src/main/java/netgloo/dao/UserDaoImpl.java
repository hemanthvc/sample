package netgloo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Repository;

import netgloo.config.GetMongoDBConnection;
import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import netgloo.models.UserRoles;

import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	@Override
	public void saveUser(User user) {
		// TODO Auto-generated method stub
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		mongoOperation.save(user, "User");
	}

	@Override
	public List<netgloo.models.User> getUsers() {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		List<netgloo.models.User> users = mongoOperation.findAll(netgloo.models.User.class);

		System.out.println("Number of users = " + users.size());
		return users;
	}

	@Override
	public List<Country> getCountry() {

		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		List<Country> listCountry = mongoOperation.findAll(Country.class);
		System.out.println("Number of country = " + listCountry.size());
		return listCountry;
	}

	@Override
	public List<States> getStates(String country) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		Query query3 = new Query();
		query3.addCriteria(Criteria.where("country_id").is(country));

		System.out.println(query3.toString());
		List<States> states = new ArrayList<States>();
		states = mongoOperation.find(query3, States.class);

		System.out.println("Number of states = " + states.size());

		return states;
	}

	@Override
	public List<UserRoles> getUserRoles() {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();

		List<UserRoles> roles = mongoOperation.findAll(UserRoles.class);

		System.out.println("Number of roles = " + roles.size());
		return roles;
	}

	@Override
	public String validateUser(String username,String password) {
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		String result = "FAIL";
		Query query3 = new Query();
		query3.addCriteria(Criteria.where("username").is(username).andOperator(Criteria.where("password").is(password)));

		System.out.println(query3.toString());

		netgloo.models.User user = mongoOperation.findOne(query3, netgloo.models.User.class);

		if (null != user)
			result = "PASS";

		System.out.println("Number of states = " + result);

		return result;
	}

	@Override
	public List<netgloo.models.User> editUser(User user) {
		
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(user.getUsername()));
		System.out.println(query+"---"+user.getFirstname()+"----"+user.getUsername());
		netgloo.models.User userTest1 = mongoOperation.findOne(query, netgloo.models.User.class);
		userTest1.setFirstname(user.getFirstname());
		userTest1.setLastname(user.getLastname());
		userTest1.setPassword(user.getPassword());
		userTest1.setEmail(user.getEmail());
		userTest1.setAddress(user.getAddress());
		userTest1.setPhone(user.getPhone());
		userTest1.setSecretQuestion(user.getSecretQuestion());
		userTest1.setSecretAnswer(user.getSecretAnswer());
		
		mongoOperation.save(userTest1);

		//get the updated object again
		List<netgloo.models.User> users = mongoOperation.findAll(netgloo.models.User.class);
		
		return users;
	}
	
	@Override
	public netgloo.models.User getUser(User user) {
		
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(user.getUsername()));
		System.out.println(query);
		netgloo.models.User userTest1 = mongoOperation.findOne(query, netgloo.models.User.class);
		return userTest1;
	}

	@Override
	public List<netgloo.models.User>  deleteUser(String username) {
		// TODO Auto-generated method stub
		MongoOperations mongoOperation = GetMongoDBConnection.getConnection();
		Query query = new Query();
		query.addCriteria(Criteria.where("username").is(username));
		netgloo.models.User userTest2 = mongoOperation.findOne(query, netgloo.models.User.class);
		mongoOperation.remove(userTest2);
		
		//get the updated object again
		List<netgloo.models.User> users = mongoOperation.findAll(netgloo.models.User.class);

		
		return users;
	}
}
