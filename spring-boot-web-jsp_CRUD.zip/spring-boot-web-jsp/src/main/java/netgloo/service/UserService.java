package netgloo.service;

import java.util.List;

import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import netgloo.models.UserRoles;

public interface UserService {

	void saveUser(User user);

	List<User> getAllAccountDetails();

	void updateAccountDetails(String userId);

	void updateAccountDetailsByName(String name);

	String deleteAccount(String userId);

	List<netgloo.models.User> getUsers();

	List<Country> getCountry();

	List<States> getStates(String country);
	
	List<UserRoles> getUserRoles();
	
	String validateUser(String username,String password);
	
	List<netgloo.models.User> editUser(User user);
	
	List<netgloo.models.User> deleteUser(String username);
	
	netgloo.models.User getUser(User user);
}
