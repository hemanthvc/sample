package netgloo.models;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "States")
public class States {

	public String getState_desc() {
		return State_desc;
	}
	public void setState_desc(String state_desc) {
		State_desc = state_desc;
	}
	String state_id;
	String State_desc;
	String country_id;
	public String getState_id() {
		return state_id;
	}
	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	

	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
}
