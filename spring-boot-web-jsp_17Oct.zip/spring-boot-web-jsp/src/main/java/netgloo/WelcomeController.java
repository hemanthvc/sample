package netgloo;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import netgloo.form.ChangePasswordForm;
import netgloo.form.LoginForm;
import netgloo.form.User;

@Controller
public class WelcomeController {

	// inject via application.properties
	@Value("${welcome.message:test}")
	private String message = "Hello World";

	@RequestMapping("/")
	public ModelAndView welcome(Map<String, Object>  model) {
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("user", new User());
		System.out.println("*******************WelcomeController *************************");
		model.put("message", this.message);
		return mav;
	}
	
	
	@RequestMapping("/home")
	public String home(Map<String, Object> model) {
	
		model.put("message", this.message);
		return "welcome";
	}
	

	@RequestMapping("/register")
	public ModelAndView index(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("register");
		mav.addObject("user", new User());

		return mav;
	}

	@RequestMapping("/about")
	public ModelAndView about(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("about");
		mav.addObject("user", new User());
		return mav;
	}
	
	@RequestMapping("/changepassword")
	public ModelAndView changepassword(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("changepassword");
		mav.addObject("user", new ChangePasswordForm());
		return mav;
	}

	@RequestMapping("/login" )
	public ModelAndView login(Map<String, Object> model,HttpSession session) {
		System.out.println("----------login--------------------");
		
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("user", new LoginForm());
		
		if(null != session && null != session.getAttribute("user"))
			session.invalidate();
		
		model.put("message", this.message);
		return mav;
	}

	@RequestMapping("/403")
	public String error403() {
		return "403";
	}
	
	@RequestMapping("/forgotpassword")
	public ModelAndView forgotpassword(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("forgotpassword");
		mav.addObject("user", new User());

		return mav;
	}
	
	@RequestMapping("/logout")
	public ModelAndView logout(Map<String, Object> model,HttpSession session) {
		System.out.println("----------logout--------------------"+session);
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("user", new User());

		
		if(null != session && null != session.getAttribute("user"))
			session.invalidate();
		
		
		return mav;
	}
	

}