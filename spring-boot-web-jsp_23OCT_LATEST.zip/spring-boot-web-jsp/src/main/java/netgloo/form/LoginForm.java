package netgloo.form;

import netgloo.contraint.PasswordConstraint;
import netgloo.contraint.UserNameConstraint;

public class LoginForm {
    @UserNameConstraint
	 private String username;
    
    @PasswordConstraint
	String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password1) {
		this.password = password;
	}
}
