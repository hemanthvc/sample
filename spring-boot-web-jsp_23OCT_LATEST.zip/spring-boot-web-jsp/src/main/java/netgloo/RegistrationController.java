package netgloo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import netgloo.form.ChangePasswordForm;
import netgloo.form.LoginForm;
import netgloo.form.Result;
import netgloo.form.User;
import netgloo.models.Country;
import netgloo.models.States;
import netgloo.models.UserRoles;
import netgloo.service.UserService;

@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
public class RegistrationController {
	
	private static Logger logger = LoggerFactory.getLogger(RegistrationController.class);

	@Autowired
	public UserService userService;
	
	
	@PostMapping("/createUser")
	public ResponseEntity<?> createUser(@Valid @RequestBody User user,BindingResult result,Errors errors) {
		logger.debug("Creating User " + user.getUsername());
		String result2 = "success";
		
		
		List<Result> result1 = new ArrayList<Result>();

        //If error, just return a 400 bad request, along with the error message
		
		logger.debug("errors.hasErrors() : "+errors.hasErrors());
		
		if(result.hasErrors()) {
			Map<String ,String> errorMsg = new HashMap<String,String>();
			List<FieldError> a = result.getFieldErrors();
			for(FieldError b : a){
				Result c= new Result();
				logger.debug(b.getField()+"---"+b.getDefaultMessage());
				errorMsg.put(b.getField(), b.getDefaultMessage());
				c.setMsg(b.getDefaultMessage());
				result1.add(c);
			}
			return ResponseEntity.badRequest().body(errorMsg);
        }
        
		//user.setRole("us");
		result2 = userService.saveUser(user);
		
		logger.debug("result :"+result2);
		
		
		User user1 = new User();
		if(result2.equalsIgnoreCase("FAIL")){
			
			user1.setLastname(result2);
	            
	            return ResponseEntity.badRequest().body(user1);
		}
		user1.setLastname("PASS");
		
		return ResponseEntity.ok(user1);
	}

	@PostMapping("/state")
	public ResponseEntity<?> getState(@RequestBody User user) {
		logger.debug("in State function " + user.getCountry());
		List<States> state = new ArrayList<States>();

		logger.debug("size---" + state.size());

		state = userService.getStates(user.getCountry());

		return ResponseEntity.ok(state);
	}

	@PostMapping("/country")
	public ResponseEntity<List<Country>> getCountry(@RequestBody User user) {
		logger.debug("in getCountry function " + user.getCountry());

		List<Country> country = new ArrayList<Country>();
		country = userService.getCountry();

		return ResponseEntity.ok(country);
	}

	@PostMapping("/users")
	public ResponseEntity<List<netgloo.models.User>> getUsers(@RequestBody User user) {
		logger.debug("in getUsers function " + user.getCountry());

		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userService.getUsers(user.getUsername());

		return ResponseEntity.ok(users);
	}
	
	
	@PostMapping("/getUserOnSearch")
	public ResponseEntity<List<netgloo.models.User>> getUserOnSearch(@RequestBody User user) {
		logger.debug("in getUserOnSearch function " + user.getSearch());

		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userService.getUserOnSearch(user.getSearch());

		return ResponseEntity.ok(users);
	}

	@PostMapping("/roles")
	public ResponseEntity<List<UserRoles>> getUserRoles(@RequestBody User user) {
		logger.debug("in getUsers function " + user.getCountry());

		List<UserRoles> roles = new ArrayList<UserRoles>();
		roles = userService.getUserRoles();

		return ResponseEntity.ok(roles);
	}

	@PostMapping("/login")
	public ResponseEntity<?> validateUser( @Valid @RequestBody LoginForm user,Errors errors,BindingResult result,HttpServletRequest request, HttpSession httpSession) {
		
		
		/*logger.debug("in validateUser function " + user.getPassword1());
		
		List<Result> result1 = new ArrayList<Result>();

        //If error, just return a 400 bad request, along with the error message
		
		logger.debug("errors.hasErrors() : "+errors.hasErrors());
		
		if(result.hasErrors()) {
			Map<String ,String> errorMsg = new HashMap<String,String>();
			
		
			List<FieldError> a = result.getFieldErrors();
			
		
			
			for(FieldError b : a){
				Result c= new Result();
				logger.debug(b.getField()+"---"+b.getDefaultMessage());
				errorMsg.put(b.getField(), b.getDefaultMessage());
				c.setMsg(b.getDefaultMessage());
				result1.add(c);
			}
			return ResponseEntity.badRequest().body(errorMsg);
        }
        
     		request.getSession().setAttribute("user", user.getUsername());
        
		User user1 = new User();
		String result2 = userService.validateUser(user.getUsername(),user.getPassword1());
		String[] response = result2.split("-");
		logger.debug("Role : "+response[1]);
		request.getSession().setAttribute("role", response[1]);
		
		logger.debug(result2);
		
		user1.setLastname(response[0]);*/

		return  ResponseEntity.ok(null);
	}
	
	@PostMapping("/editUser")
	public ResponseEntity<List<netgloo.models.User>> editUser(@RequestBody User user) {
		logger.debug("in editUser function " + user.getUsername());
	
		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		
		logger.debug("locked : "+user.getLocked());
		
		users = userService.editUser(user);
		

		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/deleteUser")
	public ResponseEntity<List<netgloo.models.User>> deleteUser(@RequestBody User user) {
		logger.debug("in deleteUser function " + user.getUsername());
		List<netgloo.models.User> users = new ArrayList<netgloo.models.User>();
		users = userService.deleteUser(user.getUsername());
		

		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/getUser")
	public ResponseEntity<netgloo.models.User> getUser(@RequestBody User user) {
		logger.debug("in getUser function " + user.getUsername());
	
		
		netgloo.models.User users = new netgloo.models.User();
		
		users = userService.getUser(user);
			

		return ResponseEntity.ok(users);
	}
	
	
	
	@PostMapping("/getUserLike")
	public ResponseEntity<netgloo.models.User> getUserLike(@RequestBody User user) {
		logger.debug("in getUser function " + user.getUsername());
	
		
		netgloo.models.User users = new netgloo.models.User();
		
		users = userService.getUserLike(user);
			

		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/getSecretQuestion")
	public ResponseEntity<netgloo.models.User> getSecretQuestion(@RequestBody User user) {
		logger.debug("in getSecretQuestion function " + user.getUsername());
		netgloo.models.User users = new netgloo.models.User();
		users   = userService.getSecretQuestion(user.getUsername());
		
		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/validateSecretAnswer")
	public ResponseEntity<?> validateSecretAnswer(@RequestBody User user) {
		logger.debug(user.getUsername()+"--in validateSecretAnswer function " + user.getSecretAnswer());
		netgloo.models.User users = new netgloo.models.User();
		users  = userService.validateSecretQuestion(user.getUsername(),user.getSecretAnswer());
	
		return ResponseEntity.ok(users);
	}
	
	@PostMapping("/resetPassword")
	public ResponseEntity<?> resetPassword(@RequestBody User user) {
		logger.debug(user.getUsername()+"--in resetPassword function " + user.getPassword()+"---"+user.getNewpassword());
		netgloo.models.User users = new netgloo.models.User();
		users  = userService.resetPassword(user.getPassword(),user.getNewpassword(),user.getUsername());
	
		return ResponseEntity.ok(users);
	}
	
	
	@PostMapping("/getUserByGroup")
	public ResponseEntity<Map<String,String>> getUserByGroup(@RequestBody User user) {
		logger.debug(user.getUsername()+"--in resetPassword function " + user.getPassword()+"---"+user.getNewpassword());
		
		Map<String,String> dataMap  = userService.getGroupByUser();
	
		return ResponseEntity.ok(dataMap);
	}
	
		
	
	@PostMapping("/changePassword")
	public ResponseEntity<?> changePassword(@Valid @RequestBody ChangePasswordForm user,Errors errors,BindingResult result) {
		logger.debug("--in changePassword function " + user.getOldPassword()+"---"+user.getNewPassword());
		
		List<Result> result1 = new ArrayList<Result>();

		ChangePasswordForm form = new ChangePasswordForm();
        //If error, just return a 400 bad request, along with the error message
		
		logger.debug("errors.hasErrors() : "+errors.hasErrors());
		
		if(result.hasErrors()) {
			Map<String ,String> errorMsg = new HashMap<String,String>();
			
		
			List<FieldError> a = result.getFieldErrors();
			
		
			
			for(FieldError b : a){
				Result c= new Result();
				logger.debug(b.getField()+"---"+b.getDefaultMessage());
				errorMsg.put(b.getField(), b.getDefaultMessage());
				c.setMsg(b.getDefaultMessage());
				result1.add(c);
			}
			return ResponseEntity.badRequest().body(errorMsg);
        }
		
		String response  = userService.changePassword(user.getOldPassword(),user.getNewPassword(),user.getUserName());
		form.setResult(response);
		return ResponseEntity.ok(form);
	}

}