package netgloo.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationUtil {
	
	  public static boolean validateRegex(String regex,String data){
	    	Pattern p = Pattern.compile(regex);
			 Matcher m = p.matcher(data);
			 boolean b = m.find();
			 System.out.println("-----ValidationUtil----------"+b);
			 return b;
	    }

}
