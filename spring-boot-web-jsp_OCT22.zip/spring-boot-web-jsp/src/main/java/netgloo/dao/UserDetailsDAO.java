package netgloo.dao;

import netgloo.models.UserAttempts;

public interface UserDetailsDAO {
	void updateFailAttempts(String username);
	void resetFailAttempts(String username);
	UserAttempts getUserAttempts(String username);
}
