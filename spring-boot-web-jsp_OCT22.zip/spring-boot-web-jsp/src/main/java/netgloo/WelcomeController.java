package netgloo;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import netgloo.form.ChangePasswordForm;
import netgloo.form.LoginForm;
import netgloo.form.User;

@Controller
public class WelcomeController {
	
	private static Logger logger = LoggerFactory.getLogger(WelcomeController.class);

	// inject via application.properties
	@Value("${welcome.message:test}")
	private String message = "Hello World";

	@RequestMapping("/")
	public ModelAndView welcome(Map<String, Object>  model) {
		
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("user", new LoginForm());
		logger.info("*******************WelcomeController *************************");
		model.put("message", this.message);
		return mav;
	}
	
	  @GetMapping("/403")
	    public String error403() {
	        return "/error/403";
	    }
	
	
	@RequestMapping("/home")
	public String home(Map<String, Object> model) {
	
		model.put("message", this.message);
		return "welcome";
	}
	

	

	@RequestMapping("/register")
	public ModelAndView index(Map<String, Object> model) {
		logger.debug("in register flow");
		ModelAndView mav = new ModelAndView("register");
		mav.addObject("user", new User());

		return mav;
	}
	
	@RequestMapping("/editUser")
	public ModelAndView editUser(Map<String, Object> model) {
		logger.debug("in register flow");
		ModelAndView mav = new ModelAndView("editUser");
		mav.addObject("user", new User());

		return mav;
	}
	
	

	@GetMapping("/about")
	public ModelAndView about(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("about");
		mav.addObject("user", new User());
		return mav;
	}
	
	/*@GetMapping("/about")
	public String about(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("about");
		mav.addObject("user", new User());
		return "about";
	}*/
	
	@GetMapping("/logout")
	public String logout(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("about");
		mav.addObject("user", new User());
		return "logout";
	}
	
	@RequestMapping("/changepassword")
	public ModelAndView changepassword(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("changepassword");
		mav.addObject("user", new ChangePasswordForm());
		return mav;
	}
	
	@RequestMapping("/usercharts")
	public ModelAndView usercharts(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("usercharts");
		mav.addObject("user", new ChangePasswordForm());
		return mav;
	}

	@RequestMapping("/login" )
	public ModelAndView login(Map<String, Object> model,HttpSession session) {
		System.out.println("----------login--------------------");
		
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("user", new LoginForm());
		
		if(null != session && null != session.getAttribute("user"))
			session.invalidate();
		
		model.put("message", this.message);
		return mav;
	}

	@RequestMapping("/forgotpassword")
	public ModelAndView forgotpassword(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("forgotpassword");
		mav.addObject("user", new User());

		return mav;
	}
	
	@RequestMapping("/logout")
	public ModelAndView logout(Map<String, Object> model,HttpSession session) {
		logger.debug("----------logout--------------------"+session);
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("user", new User());

		
		if(null != session && null != session.getAttribute("user"))
			session.invalidate();
		
		
		return mav;
	}
	

}