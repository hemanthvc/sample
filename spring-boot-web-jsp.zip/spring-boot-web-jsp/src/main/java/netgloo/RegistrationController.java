package netgloo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import netgloo.form.User;
import netgloo.service.UserService;

@RestController
public class RegistrationController {
	
	@Autowired
	public UserService userService;	
	
	
		@PostMapping("/createUser")
		public ResponseEntity<?> createUser(@RequestBody User user) {
	        System.out.println("Creating User " + user.getUsername());
	 
	       String result = "success";
	       
	       List<String> country = new ArrayList();
	       country.add("India");
	       country.add("US");
	 
	       // userService.saveUser(user);
	 
	        return ResponseEntity.ok(result);
	    }
	 
		
		@PostMapping("/state")
		public ResponseEntity<?> getState(@RequestBody User user) {
	        System.out.println("in State function " + user.getCountry());
	        List<String> state = new ArrayList();
	        
	          if(!"select".equalsIgnoreCase(user.getCountry())){
	        	state.add("Karnataka");
	        	state.add("Andra");
	          }
	        
	        
	      
	       String result = "success";
	 
	       // userService.saveUser(user);
	 
	        return ResponseEntity.ok(state);
	    }
		
		
		@PostMapping("/country")
		public ResponseEntity<?> getCountry(@RequestBody User user) {
	        System.out.println("in getCountry function " + user.getCountry());
	       	        
	        List<String> country = new ArrayList();
		       country.add("India");
		       country.add("US");
		 
	 
	        return ResponseEntity.ok(country);
	    }
	 
	
	 

}