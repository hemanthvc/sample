package netgloo.service;

import java.util.List;

import netgloo.models.User;

public interface UserService {

	void createAccount(User user);

	List<User> getAllAccountDetails();

	void updateAccountDetails(String userId);

	void updateAccountDetailsByName(String name);

	String deleteAccount(String userId);
}
