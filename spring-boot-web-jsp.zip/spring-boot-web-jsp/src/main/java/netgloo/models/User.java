package netgloo.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "registeruser")
public class User {

	private String user_Id;
	private String password;
	private String email;
	private String username;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	private String firstname;
	private String lastname;
	private String address;
	private String country;
	private String state;
	private String district;
	//private int pincode;
	//private Role role;
	//private UserRole userRole;

	public User(){
		
	}
	public User(String user_id){
		this.user_Id = user_id;
	}
	
	public User(String user_Id, String password, String email,  String firstname,
			String lastname, String address, String country, String state, String district ) {
		super();
		this.user_Id = user_Id;
		this.password = password;
		this.email = email;
		//this.mobilenumber = mobilenumber;
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.country = country;
		this.state = state;
		this.district = district;
		//this.pincode = pincode;
	}

	/**
	 * @return the user_Id
	 */
	@Id
	@Column(name = "user_Id")
	public String getUser_Id() {
		return user_Id;
	}
	/**
	 * @param user_Id the user_Id to set
	 */
	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}
	
	/**
	 * @return the password
	 */
	@NotNull
	@Size(min = 8, max = 20)
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	@NotNull
	@Size(min = 3, max = 80)
	public String getEmail() {
		return email;
	}

	public void setEmail(String value) {
		this.email = value;
	}

	

	/**
	 * @return the firstname
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * @param firstname
	 *            the firstname to set
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * @return the lastname
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @param lastname
	 *            the lastname to set
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the district
	 */
	public String getDistrict() {
		return district;
	}

	/**
	 * @param district
	 *            the district to set
	 */
	public void setDistrict(String district) {
		this.district = district;
	}

	/**
	 * @return the pincode
	 */
//	public int getPincode() {
//		return pincode;
//	}

	/**
	 * @param pincode
	 *            the pincode to set
	 */
//	public void setPincode(int pincode) {
//		this.pincode = pincode;
//	}
	

	
} // class User
