package netgloo.dao;

import java.util.List;

import netgloo.models.User;

public interface UserDao {
	void createAccount(User user);

	//List<User> getAllAccountDetails();

	//void updateAccountDetails(String userId);

	//void updateAccountDetailsByName(String name);

	//String deleteAccount(String userId);

}