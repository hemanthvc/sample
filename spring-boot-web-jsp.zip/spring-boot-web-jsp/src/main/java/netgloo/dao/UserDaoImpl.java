package netgloo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import netgloo.models.User;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory _sessionFactory;

	private Session getSession() {
		return _sessionFactory.getCurrentSession();
	}

	@Override
	public void createAccount(User user) {
		getSession().save(user);
		return;
	}

	/*@Override
	public List<User> getAllAccountDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateAccountDetails(String userId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAccountDetailsByName(String name) {
		// TODO Auto-generated method stub

	}

	@Override
	public String deleteAccount(String userId) {
		// TODO Auto-generated method stub
		return null;
	}*/
}
// class UserMapper implements RowMapper<User> {
// public User mapRow(ResultSet rs, int arg1) throws SQLException {
// User user = new User();
// user.setUsername(rs.getString("username"));
// user.setPassword(rs.getString("password"));
// user.setFirstname(rs.getString("firstname"));
// user.setLastname(rs.getString("lastname"));
// user.setEmail(rs.getString("email"));
// user.setAddress(rs.getString("address"));
// user.setPhone(rs.getInt("phone"));
// return user;
// }
