package netgloo.config;

public class CustomUserDetailsSecurityConfig {

}
