package netgloo.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import netgloo.contraint.*;
import netgloo.service.CustomerUserDetailsService;
import netgloo.util.ValidationUtil;

public class EmailValidator implements
  ConstraintValidator<EmailConstraint, String> {
 
	
	private static Logger logger = LoggerFactory.getLogger(EmailValidator.class);
	
    @Override
    public void initialize(EmailConstraint contactNumber) {
    	
    }
 
    @Override
    public boolean isValid(String contactField,
      ConstraintValidatorContext cxt) {
    	logger.debug("*********isValid*********"+contactField);
    	cxt.disableDefaultConstraintViolation();
    	
    	
        return checkConstraint1(contactField,cxt);
    }
    
 // Note: A private method for each constraint decreases the cyclomatic complexity.
    private boolean checkConstraint1(String contactField, ConstraintValidatorContext context) {
        // Default validity is true until proven otherwise.
        boolean valid = true;
        

        if ("".equalsIgnoreCase(contactField) || contactField == null  ) {
            valid = false;
            logger.debug("entered--1--");
            context.buildConstraintViolationWithTemplate(	
               "Email cannot be blank.").addConstraintViolation();
        }else if(contactField != null && !ValidationUtil.validateRegex("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", contactField)){
       	 valid = false;
         logger.debug("entered 3----");
         context.buildConstraintViolationWithTemplate(
            "Please enter valid email Id.").addConstraintViolation();
        
        }

        return valid;
    }
    
  
    

}
